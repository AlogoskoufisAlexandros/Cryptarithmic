package exe6;

import java.util.*;

public class exe6 {

	public static void main(String[] args) {
		
		//USER'S INPUT
		
		Scanner sc = new Scanner(System.in);
		String s1;
		String s2;
		String r;
		int base;
		System.out.println("Enter first word");
		s1=sc.nextLine();
		System.out.println("Enter secord word");
		s2=sc.nextLine();
		System.out.println("Enter result word");
		r=sc.nextLine();
		System.out.println("Enter the numeric system");
		base=sc.nextInt();
		sc.close();
		
		// ----------------------------------------------
		String chars=s1.concat(s2).concat(r);
		
		char [] letters=chars.toCharArray();

		

		
		HashMap<Character,Integer> uniqueLetters = new HashMap<Character,Integer>();
		for (char letter : letters ) {
			uniqueLetters.put(letter,-1);
		}
		
		char[] usedLetters = new char[uniqueLetters.size()];
		int j=0;
		for(char c: uniqueLetters.keySet()) {
			usedLetters[j]=c;
			j++;
		}
		j=0;
		int counter=0;	
		while(counter<Math.pow(base, usedLetters.length)){
				for(j =0;j<usedLetters.length;j++) {
					uniqueLetters.put(usedLetters[j], (int)(counter / Math.pow(base, j)) % base);
					
				}
				List<Integer> ls = new ArrayList<Integer>() ;
				for(int n : uniqueLetters.values()) {
					ls.add(n);
				}
				
				if(alldif(ls) && uniqueLetters.get(s1.charAt(0))!=0 && uniqueLetters.get(s2.charAt(0))!=0 &&uniqueLetters.get(r.charAt(0))!=0) {
					trySolve(s1, s2, r, uniqueLetters,base);
				}

				counter++;
		
		}	
		
		
		
		
	}
		
	public static void trySolve(String s1,String s2,String res, HashMap<Character,Integer> comb,int base) {
		String w1 = "";
		String w2 = "";
		String w3 = "";
		for(char c : s1.toCharArray() ) {
			w1=w1+comb.get(c).toString();
		}
		for(char c : s2.toCharArray() ) {
			w2=w2+comb.get(c).toString();
		}
		for(char c : res.toCharArray() ) {
			w3=w3+comb.get(c).toString();
		}
		
		
		
		int val1=Integer.parseInt((Integer.toString(Integer.parseInt(w1,base),10)));
		int val2=Integer.parseInt((Integer.toString(Integer.parseInt(w2,base),10)));
		int val3=Integer.parseInt((Integer.toString(Integer.parseInt(w3,base),10)));
		
		
		if(val1+val2==val3) {
			System.out.println(comb);
		}
		
		
	}
		
		
	
	
	public static boolean alldif(List<Integer> answer) {
		if(answer.size()==1) {
			return true;
		}
		int popped=answer.remove(1);
			if(answer.contains(popped)) 
				return false;
			
		return alldif(answer);
		}
		
		
	}


